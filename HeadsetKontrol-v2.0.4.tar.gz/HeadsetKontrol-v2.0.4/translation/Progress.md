|  Locale  |  Lines  | % Done|
|----------|---------|-------|
| Template |     105 |       |
| vi       |     105 |  100% |
